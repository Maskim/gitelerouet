<?php

//define needed constants
define( 'ELATED_CPT_VERSION', '1.1.3' );
define( 'ELATED_CPT_ABS_PATH', dirname( __FILE__ ) );
define( 'ELATED_CPT_REL_PATH', dirname( plugin_basename( __FILE__ ) ) );
define( 'ELATED_CPT_URL_PATH', plugin_dir_url( __FILE__ ) );
define( 'ELATED_CPT_MODULES_PATH', ELATED_CPT_ABS_PATH . '/modules' );
define( 'ELATED_CPT_MODULES_URL_PATH', ELATED_CPT_URL_PATH . 'modules' );